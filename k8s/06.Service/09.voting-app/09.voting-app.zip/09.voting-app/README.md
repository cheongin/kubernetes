본 소스 코드는 오픈된 소스 코드에서 k8s-specifications/vote-service.yaml 파일의 내용을 변경한 것임
원본 파일에 대한 정보는 https://github.com/dockersamples/example-voting-app 홈페이지 참조